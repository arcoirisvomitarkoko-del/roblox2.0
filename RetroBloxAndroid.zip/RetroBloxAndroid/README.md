# RetroBlox Android

Protótipo independente de catálogo de jogos e loja retrô para Android, feito com Kotlin e Jetpack Compose.

## O que já funciona
- Navegação entre Início, Jogos, Loja, Avatar e Perfil.
- Catálogo de experiências demonstrativas.
- Loja com preços fictícios em RetroBux.
- Saldo ilimitado representado por `∞ RetroBux`.
- Aquisição local de itens e inventário/equipamento durante a sessão.
- Interface inspirada em portais de jogos antigos, sem copiar marcas, imagens ou ativos oficiais.

## Limites desta versão
Este é um protótipo de interface e economia local, não um jogo 3D multiplayer. Os jogos listados são exemplos e não são experiências jogáveis completas. O inventário fica apenas na memória e reinicia quando o app é fechado. Os preços são valores fictícios inspirados em jogos antigos, não preços históricos verificados do Roblox em 2010.

## Como abrir e executar
1. Instale o Android Studio (versão compatível com Android Gradle Plugin 8.7.3).
2. Extraia o ZIP.
3. No Android Studio, escolha **Open** e selecione a pasta `RetroBloxAndroid`.
4. Aguarde a sincronização do Gradle. Use JDK 17.
5. Inicie um emulador Android (API 23 ou superior) ou conecte um aparelho com depuração USB.
6. Clique em **Run**.

## Estrutura
```text
RetroBloxAndroid/
├── settings.gradle.kts
├── build.gradle.kts
├── gradle.properties
└── app/
    ├── build.gradle.kts
    └── src/main/
        ├── AndroidManifest.xml
        └── java/com/example/retroblox/MainActivity.kt
```

## Próximas etapas para virar um jogo completo
- Criar uma cena 3D com Unity ou Godot.
- Adicionar movimento do personagem, câmera e colisões.
- Criar editor de mapas e sistema de publicação.
- Persistir perfil e inventário com Room.
- Para multiplayer, desenvolver um servidor próprio com autenticação, salas e validação de compras.

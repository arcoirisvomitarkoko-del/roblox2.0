package com.example.retroblox

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val OldBlue = Color(0xFF6E99C9)
private val PageGray = Color(0xFFE7E7E7)
private val PanelGray = Color(0xFFF7F7F7)
private val Ink = Color(0xFF333333)
private val Green = Color(0xFF78A64A)
private val Gold = Color(0xFFFFD34E)

data class Game(val title: String, val creator: String, val players: String, val description: String, val icon: String)
data class ShopItem(val name: String, val category: String, val price: Int, val icon: String)

private val games = listOf(
    Game("Clássico: Ilha das Aventuras", "RetroBuilder", "128 jogando", "Explore uma ilha cheia de plataformas e segredos.", "🏝️"),
    Game("Corrida de Carrinhos", "PixelRacer", "86 jogando", "Dispute corridas em pistas coloridas.", "🏎️"),
    Game("Sobrevivência na Torre", "BlockMaster", "54 jogando", "Suba a torre e encontre o caminho até o topo.", "🗼"),
    Game("Cidade de Blocos", "OldStudio", "203 jogando", "Passeie por uma cidade construída com blocos.", "🏙️"),
    Game("Esconde-Esconde", "RetroBuilder", "41 jogando", "Encontre os jogadores escondidos pelo mapa.", "🔎")
)

private val shopItems = listOf(
    ShopItem("Chapéu de Explorador", "Chapéus", 25, "🎩"),
    ShopItem("Coroa Dourada Retrô", "Chapéus", 100, "👑"),
    ShopItem("Óculos Pixel", "Rostos e acessórios", 15, "🕶️"),
    ShopItem("Asas Clássicas", "Acessórios", 75, "🪽"),
    ShopItem("Camisa Azul Quadrada", "Roupas", 10, "👕"),
    ShopItem("Capa Vermelha", "Acessórios", 50, "🧣")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { RetroBloxApp() }
    }
}

@Composable
fun RetroBloxApp() {
    var selectedTab by remember { mutableStateOf("Início") }
    var selectedGame by remember { mutableStateOf<Game?>(null) }
    var ownedItems by remember { mutableStateOf(setOf<String>()) }
    var equippedItems by remember { mutableStateOf(setOf<String>()) }
    var notice by remember { mutableStateOf("Bem-vindo ao RetroBlox!") }

    MaterialTheme {
        Scaffold(
            containerColor = PageGray,
            topBar = {
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth().background(OldBlue).padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("RetroBlox", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Black)
                        Column(horizontalAlignment = Alignment.End) {
                            Text("RETROBUX", color = Color.White, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text("∞", color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Black)
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth().background(Color(0xFF4D719B)).padding(8.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        listOf("Início", "Jogos", "Loja", "Avatar", "Perfil").forEach { tab ->
                            Text(
                                tab,
                                color = Color.White,
                                fontWeight = if (selectedTab == tab) FontWeight.Black else FontWeight.Medium,
                                modifier = Modifier.clickable {
                                    selectedTab = tab
                                    selectedGame = null
                                }.padding(horizontal = 7.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            },
            bottomBar = {
                Row(
                    modifier = Modifier.fillMaxWidth().background(Color(0xFFD2D2D2)).padding(8.dp),
                    horizontalArrangement = Arrangement.Center
                ) {
                    Text("RetroBlox • Projeto independente • v1.0", color = Ink, fontSize = 11.sp)
                }
            }
        ) { padding ->
            Column(
                modifier = Modifier.fillMaxSize().padding(padding).padding(12.dp)
            ) {
                Text(notice, color = Color(0xFF486D35), fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(8.dp))

                if (selectedGame != null) {
                    GameDetails(game = selectedGame!!, onBack = { selectedGame = null })
                } else {
                    when (selectedTab) {
                        "Início" -> HomeScreen(
                            onOpenGames = { selectedTab = "Jogos" },
                            onOpenShop = { selectedTab = "Loja" },
                            onOpenGame = { selectedGame = it }
                        )
                        "Jogos" -> GamesScreen(onOpenGame = { selectedGame = it })
                        "Loja" -> ShopScreen(
                            ownedItems = ownedItems,
                            onBuy = { item ->
                                ownedItems = ownedItems + item.name
                                notice = "${item.name} adicionado ao inventário!"
                            }
                        )
                        "Avatar" -> AvatarScreen(
                            ownedItems = ownedItems,
                            equippedItems = equippedItems,
                            onEquip = { item ->
                                equippedItems = if (item in equippedItems) equippedItems - item else equippedItems + item
                                notice = if (item in equippedItems) "$item removido." else "$item equipado!"
                            }
                        )
                        else -> ProfileScreen(ownedItems = ownedItems, equippedItems = equippedItems)
                    }
                }
            }
        }
    }
}

@Composable
fun HomeScreen(onOpenGames: () -> Unit, onOpenShop: () -> Unit, onOpenGame: (Game) -> Unit) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            RetroPanel {
                Text("Bem-vindo ao mundo de blocos!", fontSize = 20.sp, fontWeight = FontWeight.Black, color = Ink)
                Text("Uma experiência retrô feita por você.", color = Ink, fontSize = 13.sp)
                Spacer(Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = onOpenGames, colors = ButtonDefaults.buttonColors(containerColor = Green)) { Text("Explorar jogos") }
                    OutlinedButton(onClick = onOpenShop) { Text("Abrir loja") }
                }
            }
        }
        item { SectionTitle("Jogos em destaque") }
        items(games.take(3)) { game ->
            GameCard(game = game, onClick = { onOpenGame(game) })
        }
    }
}

@Composable
fun GamesScreen(onOpenGame: (Game) -> Unit) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item { SectionTitle("Todos os jogos") }
        items(games) { game -> GameCard(game = game, onClick = { onOpenGame(game) }) }
    }
}

@Composable
fun GameCard(game: Game, onClick: () -> Unit) {
    RetroPanel {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier.size(76.dp).background(Color(0xFFD9E7F4), RoundedCornerShape(6.dp)),
                contentAlignment = Alignment.Center
            ) { Text(game.icon, fontSize = 38.sp) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(game.title, fontWeight = FontWeight.Bold, color = Ink, fontSize = 16.sp)
                Text("Criador: ${game.creator}", color = Color.DarkGray, fontSize = 11.sp)
                Text(game.players, color = Green, fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
        }
        Spacer(Modifier.height(8.dp))
        Text(game.description, color = Ink, fontSize = 12.sp)
        Button(
            onClick = onClick,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Green)
        ) { Text("Ver experiência") }
    }
}

@Composable
fun GameDetails(game: Game, onBack: () -> Unit) {
    RetroPanel {
        Text("${game.icon}  ${game.title}", fontSize = 21.sp, fontWeight = FontWeight.Black, color = Ink)
        Spacer(Modifier.height(8.dp))
        Text(game.description, color = Ink)
        Text("Criado por ${game.creator}", color = Color.DarkGray, fontSize = 12.sp)
        Text(game.players, color = Green, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(12.dp))
        Text("Prévia do jogo", fontWeight = FontWeight.Bold, color = Ink)
        Box(
            modifier = Modifier.fillMaxWidth().height(170.dp).background(Color(0xFFB8D5A2), RoundedCornerShape(6.dp)),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("🟩 🟩 🟩", fontSize = 30.sp)
                Text("MUNDO DE BLOCOS", color = Color(0xFF35552A), fontWeight = FontWeight.Black)
                Text("Área de jogo demonstrativa", color = Color(0xFF35552A), fontSize = 11.sp)
            }
        }
        Spacer(Modifier.height(10.dp))
        Text("Esta versão apresenta o catálogo e a prévia visual. A fase 3D jogável poderá ser adicionada com um motor como Unity ou Godot.", color = Ink, fontSize = 12.sp)
        Button(onClick = onBack, modifier = Modifier.fillMaxWidth()) { Text("Voltar") }
    }
}

@Composable
fun ShopScreen(ownedItems: Set<String>, onBuy: (ShopItem) -> Unit) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            RetroPanel {
                Text("Loja clássica", color = Ink, fontWeight = FontWeight.Black, fontSize = 21.sp)
                Text("Saldo: ∞ RetroBux", color = Color(0xFF9A7200), fontWeight = FontWeight.Bold)
                Text("Os valores são preços fictícios inspirados em jogos antigos, não uma tabela histórica oficial.", color = Ink, fontSize = 11.sp)
            }
        }
        items(shopItems) { item ->
            RetroPanel {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(item.icon, fontSize = 35.sp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(item.name, color = Ink, fontWeight = FontWeight.Bold)
                        Text(item.category, color = Color.DarkGray, fontSize = 11.sp)
                        Text("${item.price} RetroBux", color = Color(0xFF9A7200), fontWeight = FontWeight.Bold)
                    }
                    if (item.name in ownedItems) {
                        Text("Adquirido", color = Green, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    } else {
                        Button(
                            onClick = { onBuy(item) },
                            colors = ButtonDefaults.buttonColors(containerColor = Green)
                        ) { Text("Obter") }
                    }
                }
            }
        }
    }
}

@Composable
fun AvatarScreen(ownedItems: Set<String>, equippedItems: Set<String>, onEquip: (String) -> Unit) {
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            RetroPanel {
                Text("Meu avatar", color = Ink, fontWeight = FontWeight.Black, fontSize = 21.sp)
                Box(
                    modifier = Modifier.fillMaxWidth().height(150.dp).background(Color(0xFFE8EEF5), RoundedCornerShape(6.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("🙂", fontSize = 48.sp)
                        Text("🟦  🟫  🟦", fontSize = 25.sp)
                        Text("Avatar clássico", color = Ink, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
        item { SectionTitle("Itens disponíveis") }
        if (ownedItems.isEmpty()) {
            item { Text("Você ainda não tem itens. Visite a loja para obter acessórios.", color = Ink) }
        }
        items(ownedItems.toList()) { item ->
            RetroPanel {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(item, color = Ink, modifier = Modifier.weight(1f))
                    OutlinedButton(onClick = { onEquip(item) }) {
                        Text(if (item in equippedItems) "Desequipar" else "Equipar")
                    }
                }
            }
        }
    }
}

@Composable
fun ProfileScreen(ownedItems: Set<String>, equippedItems: Set<String>) {
    RetroPanel {
        Text("Perfil do jogador", color = Ink, fontWeight = FontWeight.Black, fontSize = 21.sp)
        Text("Jogador: Convidado", color = Ink)
        Text("Moeda: ∞ RetroBux", color = Color(0xFF9A7200), fontWeight = FontWeight.Bold)
        Text("Itens no inventário: ${ownedItems.size}", color = Ink)
        Text("Itens equipados: ${equippedItems.size}", color = Ink)
        Text("Conta local de demonstração", color = Color.DarkGray, fontSize = 11.sp)
    }
}

@Composable
fun SectionTitle(title: String) {
    Text(title, color = Color(0xFF3D5F85), fontSize = 18.sp, fontWeight = FontWeight.Black)
}

@Composable
fun RetroPanel(content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier = Modifier.fillMaxWidth()
            .background(PanelGray, RoundedCornerShape(7.dp))
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(5.dp),
        content = content
    )
}
